import csv

input_file = r'C:\Users\HP\Desktop\Darsh\Gig Earning Optimizer\clean data\gigs_skills.csv'
output_file = r'C:\Users\HP\Desktop\Darsh\Gig Earning Optimizer\clean data\gigs_skills_fixed.csv'

# Read with csv module
with open(input_file, 'r', encoding='utf-8', errors='ignore', newline='') as infile:
    reader = csv.reader(infile)
    rows = list(reader)

# Process each row
fixed_rows = []
for row in rows:
    fixed_row = []
    for field in row:
        # Replace & with 'and'
        field = field.replace('&', 'and')
        # Remove non-ASCII characters
        field = field.encode('ascii', 'ignore').decode('ascii')
        fixed_row.append(field)
    fixed_rows.append(fixed_row)

# Write with proper CSV formatting
with open(output_file, 'w', encoding='utf-8', newline='') as outfile:
    writer = csv.writer(outfile, quoting=csv.QUOTE_MINIMAL)
    writer.writerows(fixed_rows)

print(f"Fixed {len(fixed_rows)} rows successfully")
